<?php
session_start();

require 'config.php';

if (isset($_GET['id'])) {
   $Bengkel = $collection->findOne(['_id' => new MongoDB\BSON\ObjectID($_GET['id'])]);
}

if (isset($_POST['submit'])) {
   $collection->updateOne(
      ['_id' => new MongoDB\BSON\ObjectID($_GET['id'])],
      ['$set' => ['nama_pemilik' => $_POST['nama_pemilik'], 'no_kendaraan' => $_POST['no_kendaraan'], 'keluhan' => $_POST['keluhan'], 'waktu_pengambilan' => $_POST['waktu_pengambilan']]]
   );
   $_SESSION['success'] = "Data Service Berhasil Diupdate";
   header("Location: index.php");
}
?>
<style>
body {
  background-attachment: fixed;
  background-size: 100% 96%;
}
</style>

<!DOCTYPE html>
<html>
<head>
   <title>BENGKEL TUGAS BDL</title>
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>

<body>
   <div class="container">
      <h1 align="center">Edit Data Service Kendaraan</h1>
      <a href="index.php" class="btn btn-primary">Kembali</a>

      <form method="POST">
         <div class="form-group">
            <strong>Nama Pemilik</strong>
            <input type="text" name="nama_pemilik" value="<?php echo $Bengkel->nama_pemilik; ?>" required="" class="form-control" placeholder="Input Nama Pemilik Kendaraan">
         </div>
         <div class="form-group">
            <strong>Nomer Kendaraaan</strong>
            <input type="text" name="no_kendaraan" value="<?php echo $Bengkel->no_kendaraan; ?>" required="" class="form-control" placeholder="Input Plat Nomer Kendaraan">
         </div>
         <div class="form-group">
            <strong>keluhan</strong>
            <textarea class="form-control" name="keluhan" placeholder="Input Keluhan Customer" placeholder="Detail"><?php echo $Bengkel->keluhan; ?></textarea>
         </div>
         <strong>waktu pengambilan</strong>
      <input name="waktu_pengambilan" value="<?php echo $Bengkel->waktu_pengambilan; ?>" class="form-control" type="datetime-local">
</div>
<div class="form-group">
<style>
.vertical-center {
  margin: 0;
  position: absolute;
  top: 41%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
</style>

<div class="container">
  <div class="vertical-center">        
    <button type="submit" name="submit" class="btn btn-success">Submit</button>
         </div>
      </form>
   </div>
</body>
</html>