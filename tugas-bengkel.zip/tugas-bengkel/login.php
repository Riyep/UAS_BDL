<?php
   session_start();   
   if(isset($_POST['submit'])) {
    require 'config.php';

    $insertOneResult = $collections->insertOne([
        'email' => $_POST['email'],
        'password' => $_POST['password'],
    ]);

    $_SESSION['success'] = "Data Service Bengkel Berhasil Ditambahkan";
    header("Location: index.php");
 }
?>
<!DOCTYPE html>
<html>
<head>
   <title>Aplikasi Bengkel</title>
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
   <div class="container">
   <h1 style="background-color:white;" align="center">TUGAS BENGKEL BDL</h1>
  
  <form method="POST">
  <div class="form-outline mb-4">
    <label class="form-label" for="form2Example1">Email address</label>
    <input type="email" name="email" id="form2Example1" class="form-control" />
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form2Example2">Password</label>
    <input type="password" name="password"id="form2Example2" class="form-control" />
  </div>

  <div class="row mb-4">
    <div class="col d-flex justify-content-center">
      <!-- Checkbox -->
      <div class="form-check">
        <label class="form-check-label" for="form2Example34">   </label>
      </div>
    </div>
  </div>

  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block mb-4">Log in</button>

  <div class="text-center">
    <p>Not a member? <a href="#!">Register</a></p>
  </div>
</form>
  </div>
</form>