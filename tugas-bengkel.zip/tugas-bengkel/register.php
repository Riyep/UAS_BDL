
<?php
  session_start();
  if(isset($_POST['submit'])) {
     require 'config.php';

     $insertOneResult = $collection->$List_User([
         'name' => $_POST['name'],
         'alamat' => $_POST['alamat'],
         'telp' => $_POST['telp'],
         'email' => $_POST['email'],
         'password' => $_POST['password']
     ]);

     $_SESSION['success'] = "Data Service Bengkel Berhasil Ditambahkan";
     header("Location: index.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
   <title>Aplikasi Bengkel</title>
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
   <div class="container">
   <h1 style="background-color:white;" align="center">Registrasi User</h1>
   <div class="container">
        <a href="index.php" class="btn btn-primary">Kembali</a>

        <form method="POST">
<form>
  <!-- 2 column grid layout with text inputs for the first and last names -->
  <div class="row mb-4">
    <div class="col">
      <div class="form-outline">
        <label class="form-label" for="form6Example1">Nama</label>
        <input type="text" id="form6Example1" class="form-control" />
      </div>
   

  <!-- Text input -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form6Example3">Alamat</label>
    <input type="text" name="name" id="form6Example3" class="form-control" />
  </div>

  <!-- Text input -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form6Example4">No. Telp</label>
    <input type="text" name="telp" id="form6Example4" class="form-control" />
  </div>

  <!-- Email input -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form6Example5">Email</label>
    <input type="email" name="email" id="form6Example5" class="form-control" />
  </div>

  <!-- Number input -->
  <div class="form-outline mb-4">
    <label class="form-label" for="form6Example6">Password</label>
    <input type="paassword" name="password"  id="form6Example6" class="form-control" />
  </div>

  <!-- Checkbox -->
  <div class="form-check d-flex justify-content-center mb-4">
    <input class="form-check-input me-2" type="checkbox" value="" id="form6Example8" checked />
    <label class="form-check-label" for="form6Example8"> Create an account? </label>
  </div>

  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block mb-4">Place order</button>
</div>
</form>