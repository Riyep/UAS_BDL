<?php
   session_start();
?>

<!DOCTYPE html>
<html>
<head>
   <title>Aplikasi Bengkel</title>
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
   <div class="container">
   <h1 style="background-color:white;" align="center">TUGAS BENGKEL BDL</h1>
   <style>
body {
  background-attachment: fixed;
  background-size: 100% 96%;
}
</style>
</style>
      <a  href="create.php" class="btn btn-success" >Tambah Data Service</a>

      <?php
         if(isset($_SESSION['success'])){
            echo "<div class='alert alert-success'>".$_SESSION['success']."</div>";
         }
      ?>

      <table class="table table-borderd"style="background-color:white;">>
         <tr>
            <th>Nama</th>
            <th>Nomer Kendaraan</th>
            <th>Keluhan</th>
            <th>waktu pengambilan motor</th>
            <th>Pilih</th>
         </tr>

         <?php
            require 'config.php';
            $Bengkel = $collection->find([]);
            foreach($Bengkel as $BDL) {
               echo "<tr>";
               echo "<td>".$BDL->nama_pemilik."</td>";
               echo "<td>".$BDL->no_kendaraan."</td>";
               echo "<td>".$BDL->keluhan."</td>";
               echo "<td>".$BDL->waktu_pengambilan."</td>";
               echo "<td>";
               echo "<a href='edit.php?id=".$BDL->_id."' class='btn btn-primary'>Edit</a>";
               echo "<a href='delete.php?id=".$BDL->_id."' class='btn btn-danger'>Delete</a>";
               echo "</td>";
               echo "</tr>";
            };
         ?>
      </table>
   </div>
</body>
</html>

<?php
session_destroy();
?>