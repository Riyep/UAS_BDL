<?php
   session_start();
   if(isset($_POST['submit'])) {
      require 'config.php';

      $insertOneResult = $collection->insertOne([
          'nama_pemilik' => $_POST['nama_pemilik'],
          'no_kendaraan' => $_POST['no_kendaraan'],
          'keluhan' => $_POST['keluhan'],
          'waktu_pengambilan' => $_POST['waktu_pengambilan']
      ]);

      $_SESSION['success'] = "Data Service Bengkel Berhasil Ditambahkan";
      header("Location: index.php");
   }
?>


<!DOCTYPE html>
<html>
<head>
    <title>BENGKEL TUGAS BDL</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>

    <div class="container">
        <h1 align="center">Buat Data Service Motor</h1>
        <a href="index.php" class="btn btn-primary">Kembali</a>

        <form method="POST">
            <div class="form-group">
                <strong>Nama Pemilik</strong>
                <input type="text" name="nama_pemilik" required="" class="form-control"
                    placeholder="Input Nama Pemilik Kendaraan">
            </div>
            <div class="form-group">
                <strong>Nomer Kendaraan</strong>
                <input type="text" name="no_kendaraan" required="" class="form-control"
                    placeholder="Input Plat Nomer Kendaraan">
            </div>
            <div class="form-group">
                <strong>Keluhan</strong>
                <textarea class="form-control" name="keluhan" placeholder="Input Keluhan Customer"></textarea>
            </div>
                        <div class="mx-auto col-5" style="margin-top: 10rem:">
               <strong>waktu pengambilan</strong>
            </div>
            <form>
               <input type="datetime-local" name="waktu_pengambilan" class="form-control"  required="" >
            </div>
    </div>
    <div class="form-group">     
    <style>
.vertical-center {
  margin: 0;
  position: absolute;
  top: 41%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
</style>

<div class="container">
  <div class="vertical-center">        
    <button type="submit" name="submit" class="btn btn-success">Submit</button>
        
  </div>
</div>

    </div>
    </form>
    </div>

</body>

</html>